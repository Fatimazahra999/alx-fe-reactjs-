function MainContent(){
    return(
             <main>
                <p>I love to visit New York, Paris, and Tokyo.</p>
            </main>
       
    );
}
export default MainContent;