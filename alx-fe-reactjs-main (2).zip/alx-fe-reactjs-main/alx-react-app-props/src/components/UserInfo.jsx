// src/components/UserInfo.jsx

import UserDetails from './UserDetails';

function UserInfo() {
  return <UserDetails />;
}

export default UserInfo;