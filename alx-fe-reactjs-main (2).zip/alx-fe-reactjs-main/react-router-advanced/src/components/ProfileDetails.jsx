import React from 'react';

const ProfileDetails = () => {
  return <div>Profile Details</div>;
};

export default ProfileDetails;