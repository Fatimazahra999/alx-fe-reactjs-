import React from 'react';

const ProfileSettings = () => {
  return <div>Profile Settings</div>;
};

export default ProfileSettings;