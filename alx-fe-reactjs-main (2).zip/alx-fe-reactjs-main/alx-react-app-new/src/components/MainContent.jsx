function MainContent() {
    return (
      <main style={{ padding: '25px', fontSize: '20px', lineHeight: '1.5', backgroundColor: 'grey', borderRadius: '10px' }}>
        <p>I love to visit New York, Paris, and Tokyo.</p>
      </main>
    );
  }
  
  export default MainContent;
  